# MachineReading
“莱斯杯”全国第一届“军事智能·机器阅读”挑战赛相关代码,主要包含ROUGE-L以及BLEU-4的Python以及Java实现
