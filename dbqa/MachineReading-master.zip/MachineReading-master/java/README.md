# 使用说明

## 引用jar包

- jackson-databind-2.9.5.jar
- jackson-core-2.9.5.jar
- jackson-annotations-2.9.5.jar
- junit-jupiter-api-5.0.0.jar
- junit-platform-commons-1.0.0.jar
- opentest4j-1.0.0.jar
- apiguardian-api-1.0.0.jar
