python -m basic.cli --batch_size 60 --sent_size_th 400 --num_steps 0 --num_epochs 1 --len_opt --cluster --num_gpus 1 --run_id $1 --data_dir data/$1
